# XFCE Menu V3.1 — Whisker + Cascading

## Target experience
Two independent launchers with one dark navy / slate / icy-blue visual language:
- **Whisker Menu:** Kali-like two-column launcher: search at top, Favorites / Recently Used / All Applications, categories on the left, apps on the right, and user/session actions below.
- **Applications Menu (Garcon):** separate cascading menu with the requested V3.1 tree.

## Install (Arch Linux, inside XFCE)
```bash
chmod +x setup.sh
./setup.sh --install-deps --add-panel-plugins
```
If packages are already installed:
```bash
./setup.sh --add-panel-plugins
```
Then open **Panel Preferences → Items**, move Whisker Menu to the far-left position, and keep Applications Menu as a separate button. In Whisker Properties configure two-column layout, search, category icons, user name and session buttons. The installer deliberately does not reset or silently reorder your panel.

## Popup commands
```bash
xfce4-popup-whiskermenu
xfce4-popup-applicationsmenu
```
Bind `xfce4-popup-applicationsmenu` in **Settings → Keyboard → Application Shortcuts** if you want a keyboard shortcut.

## About right-click
The standard desktop right-click menu is owned by **xfdesktop**. This installer does not replace it. It installs the cascading menu as a dedicated Applications Menu panel button and popup command. Replacing the desktop context menu is a separate xfdesktop customization and is not forced here.

## Assign tools to categories
XDG categories stay empty until a desktop launcher has the matching custom category. Example:
```bash
./scripts/assign-tool.py /usr/share/applications/wireshark.desktop "Red Team/Network/Network/Scanning & Enumeration"
```
The helper copies the launcher to `~/.local/share/applications/` and adds a unique category token; it does not edit system-owned files. Tools without a `.desktop` launcher need one created first. Category Manager entries are currently structural placeholders, not a completed GUI manager.

## Theme
`theme/gtk.css` is an optional GTK3 starting point. Merge it into `~/.config/gtk-3.0/gtk.css`. Actual transparency/blur depends on GTK theme, compositor and plugin version; true blur is not guaranteed.

## Uninstall
```bash
./setup.sh --uninstall
```
Restores the latest backed-up menu file and removes V3.1 launchers/category metadata. Panel plugins are left in place.
