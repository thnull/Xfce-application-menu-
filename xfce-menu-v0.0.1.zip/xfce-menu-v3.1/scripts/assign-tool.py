#!/usr/bin/env python3
import argparse,os,re,shutil,unicodedata
from pathlib import Path
def slug(s):
 s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower(); return re.sub(r'[^a-z0-9]+','-',s).strip('-')
p=argparse.ArgumentParser(description='Copy a .desktop launcher and assign it to an XFCE V3.1 category'); p.add_argument('desktop_file'); p.add_argument('category',help='e.g. Red Team/Intelligence/OSINT'); a=p.parse_args(); src=Path(a.desktop_file).expanduser()
if not src.is_file() or src.suffix!='.desktop': p.error('Provide an existing .desktop file')
token='X-APM-'+'-'.join(slug(x.strip()) for x in a.category.split('/') if x.strip()); dst=Path(os.environ.get('XDG_DATA_HOME',Path.home()/'.local/share'))/'applications'/src.name; dst.parent.mkdir(parents=True,exist_ok=True)
if dst.exists(): p.error(f'Refusing to overwrite {dst}')
shutil.copy2(src,dst); lines=dst.read_text(errors='replace').splitlines(); out=[]; inside=False; found=False
for line in lines:
 if line.strip()=='[Desktop Entry]': inside=True
 elif line.startswith('[') and line.endswith(']'): inside=False
 if inside and line.startswith('Categories='):
  cats=[x for x in line.split('=',1)[1].split(';') if x]; cats.append(token) if token not in cats else None; line='Categories='+';'.join(cats)+';'; found=True
 out.append(line)
if not found:
 for i,line in enumerate(out):
  if line.strip()=='[Desktop Entry]': out.insert(i+1,'Categories='+token+';'); found=True; break
if not found: dst.unlink(missing_ok=True); p.error('Invalid desktop entry')
dst.write_text('\n'.join(out)+'\n'); print(f'Assigned {dst} to {a.category} ({token})')
