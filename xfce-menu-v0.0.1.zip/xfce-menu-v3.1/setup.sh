#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CFG="${XDG_CONFIG_HOME:-$HOME/.config}"; DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
MD="$CFG/menus"; DD="$DATA/desktop-directories"; AD="$DATA/applications"
STATE="$HOME/.local/state/xfce-menu-v3.1"; BACK="$STATE/backup-$(date +%Y%m%d-%H%M%S)"
DEPS=0; PLUGINS=0; NORESTART=0
usage(){ echo 'Usage: ./setup.sh [--install-deps] [--add-panel-plugins] [--no-restart] [--uninstall]'; }
backup(){ [[ -e "$1" ]] || return 0; mkdir -p "$BACK$(dirname "$1")"; cp -a "$1" "$BACK$1"; }
uninstall(){ latest="$(find "$STATE" -maxdepth 1 -type d -name 'backup-*' 2>/dev/null|sort|tail -n1 || true)"; if [[ -n "$latest" && -f "$latest$MD/xfce-applications.menu" ]]; then mkdir -p "$MD"; cp -a "$latest$MD/xfce-applications.menu" "$MD/xfce-applications.menu"; else rm -f "$MD/xfce-applications.menu"; fi; rm -f "$AD/xfce-v31-cascading-menu.desktop" "$AD/xfce-v31-whisker-menu.desktop"; find "$DD" -maxdepth 1 -name 'apm-*.directory' -delete 2>/dev/null || true; echo 'V3.1 files restored/removed; panel plugins left untouched.'; }
while (($#)); do case "$1" in --install-deps) DEPS=1;; --add-panel-plugins) PLUGINS=1;; --no-restart) NORESTART=1;; --uninstall) uninstall; exit 0;; -h|--help) usage; exit 0;; *) echo "Unknown option: $1"; exit 2;; esac; shift; done
command -v xfconf-query >/dev/null || { echo 'Run inside an active XFCE session.'; exit 1; }
if ((DEPS)); then command -v pacman >/dev/null || { echo 'Arch Linux/pacman required.'; exit 1; }; sudo pacman -S --needed xfce4-panel xfce4-whiskermenu-plugin garcon; fi
mkdir -p "$MD" "$DD" "$AD" "$STATE"; backup "$MD/xfce-applications.menu"; install -m 0644 "$ROOT/menus/xfce-applications.menu" "$MD/xfce-applications.menu"
while IFS= read -r -d '' f; do backup "$DD/$(basename "$f")"; install -m 0644 "$f" "$DD/$(basename "$f")"; done < <(find "$ROOT/menus" -maxdepth 1 -name 'apm-*.directory' -print0)
cat > "$AD/xfce-v31-cascading-menu.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=XFCE V3.1 Cascading Menu
Exec=xfce4-popup-applicationsmenu
Icon=applications-other
Terminal=false
Categories=Utility;
EOF
cat > "$AD/xfce-v31-whisker-menu.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=XFCE V3.1 Whisker Menu
Exec=xfce4-popup-whiskermenu
Icon=org.xfce.whiskermenu
Terminal=false
Categories=Utility;
EOF
plugin_present(){
 local wanted="$1" id value
 while IFS= read -r id; do
  [[ "$id" =~ ^/plugins/plugin-[0-9]+$ ]] || continue
  value="$(xfconf-query -c xfce4-panel -p "$id" 2>/dev/null || true)"
  [[ "$value" == "$wanted" ]] && return 0
 done < <(xfconf-query -c xfce4-panel -l 2>/dev/null || true)
 return 1
}
if ((PLUGINS)); then
 if plugin_present whiskermenu; then echo 'Whisker Menu already exists.'; else xfce4-panel --add=whiskermenu || echo 'Add Whisker from Panel Preferences > Items.'; fi
 if plugin_present applicationsmenu; then echo 'Applications Menu already exists.'; else xfce4-panel --add=applicationsmenu || echo 'Add Applications Menu from Panel Preferences > Items.'; fi
fi
if ((!NORESTART)); then xfce4-panel -r || true; fi
cat <<'EOF'
Installed. Panel Preferences > Items: move Whisker Menu to the far left and keep Applications Menu as a separate cascading button.
Whisker popup: xfce4-popup-whiskermenu
Cascading popup: xfce4-popup-applicationsmenu
The desktop right-click menu belongs to xfdesktop and is not replaced by this setup.
EOF
